matrix1=(
    (1,2,3),
    (2,5,1),
    (5,4,3)
)
matrix2=(
    (2,4,6),
    (3,4,1),
    (3,2,1)
)
result=tuple(
    tuple(matrix1[i][j]+matrix2[i][j] for j in range(len(matrix2)))
    for i in range(len(matrix1))
)

for row in result:
    print(row)
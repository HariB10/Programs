def fact(i):
    if i==0 or i==1:
        return 1
    else:
        return i*(fact(i-1))
    
a=int(input("Enter the number: "))
print(f"Factorial of {a} is {fact(a)}")
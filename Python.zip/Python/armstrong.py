n=int(input("Enter the number: "))
og=n
arm=0
while n>0:
    rem=n%10
    arm=arm+(rem*rem*rem)
    n=n//10

if og==arm:
    print("The number is Armstrong")
else:
    print("The number is not Armstrong")
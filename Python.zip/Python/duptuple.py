num1=(1,2,2,2,4,5,6,6,7,7)
print("Tuple with duplicates",num1)
y=set(num1)
print("Tuple wiythout duplicates",y)
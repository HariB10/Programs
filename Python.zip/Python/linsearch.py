lst=[]
n=int(input("Enter the size of the list: "))

for i in range(n):
    ele=int(input("Enter the list elemnets: "))
    lst.append(ele)

print(lst)
t=int(input("Search element: "))

for i in range(n):
    if lst[i]==t:
        print("Element found at index",i)
        break
else:
    print("Element not found")
lst=[]
n=int(input("Enter the size of list: "))
for i in range(n):
    ele=int(input("Enter the list elements: "))
    lst.append(ele)

print(lst)

largest=smallest=lst[0]    
for i in range(1,n):
    if lst[i]>largest:
        largest=lst[i]
    if lst[i]<smallest:
        smallest=lst[i]

print(f"The largest number is {largest}")
print(f"The smallest number is {smallest}")
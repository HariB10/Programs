f=open('aaa.txt','r')
print(f.read())
f.close()
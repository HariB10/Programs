f=open('aaa.txt','w')
for row in range(4):
    a=(input("Enter the names: "))
    f.write(a+"\n")
f.close()
f=open('aaa.txt','w')
f.write("Naipunya School of Management")
f.close()

f=open('aaa.txt','r')
a=f.readlines()
print(a)
f.close()

f=open('aaa.txt','a')
a=f.write(" Cherthala")
f.close()

f=open('aaa.txt','r')
a=f.readlines()
print(a)
f.close()
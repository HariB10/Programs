def revstr(ele):
    return ele[::-1]
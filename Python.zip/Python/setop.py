set1={1,2,3,"python","java"}
set2={1,"h1",87,90,"hi"}

print("Union: ",set1.union(set2))
print("Intersection: ",set1 & set2)
print("Difference: ",set1 - set2)
print("Symmetric Difference: ",set1 ^ set2)
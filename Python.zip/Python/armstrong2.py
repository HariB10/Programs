def arms_check(n):
    temp=n
    arm=0
    while(n>0):
        rem=n%10
        arm=arm+(rem*rem*rem)
        n=n//10
    return arm==temp

def range_check(start,end):
    arm=[]
    for i in range(start,end+1):
        if arms_check(i):
            arm.append(i)
    return arm 

    

b=int(input("Enter the starting range: "))
c=int(input("Enter the ending range: "))
arms=[]
arms=range_check(b,c)
print(f"Armstrong numbers between {b} and {c}: ",arms)
arr = []
n=int(input("Enter the array size: "))
for i in range(n):
    element = int(input(f"Enter element {i+1}: "))
    arr.append(element)

print("array = ",arr)

def bin_search(arr, low, high, search):
    while low<=high:
        mid=(low+high)//2
        if arr[mid]==search:
            return mid
        elif arr[mid]>search:
            low=mid+1
        else:
            high=mid-1
    return -1

search=int(input("Enter the element to Search: "))
low=0
high=len(arr)-1
index = bin_search(arr, low, high, search)

if index!=-1:
    print(f"Element found at {index}")
else:
    print("Element not found")
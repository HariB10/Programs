try:
    a=int(input("Enter the first number"))

except ValueError:

    print("Invalid input! Pease enter integers only..")

else:
    if a/2==0:
        print("the number is even")
    else:
        print("The number is odd")

n=int(input("Enter the decimal number: "))
og=n
binary=""

while n>0:
    rem=n%2
    binary=str(rem)+binary
    n=n//2

print(f"The binary of {og} is {binary}")
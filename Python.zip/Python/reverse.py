from modules import reversemod
a=(input("Enter the string: "))
b=reversemod.revstr(a)
print("Reversed String is:",b)
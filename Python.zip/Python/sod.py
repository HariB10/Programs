n=int(input("Enter the number: "))
og=n
sum=0
while n>0:
    rem=n%10
    sum=rem+sum
    n=n//10

print(f"Sum of the digits of {og} is {sum}")